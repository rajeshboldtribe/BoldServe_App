const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const adminSchema = new mongoose.Schema({
  userId: {
    type: String,
    required: true,
    unique: true
  },
  password: {
    type: String,
    required: true
  }
}, {
  timestamps: true
});

adminSchema.statics.initializeAdmin = async function() {
  try {
    const adminExists = await this.findOne({ userId: 'Admin' });
    
    if (!adminExists) {
      const hashedPassword = await bcrypt.hash('Admin123', 10);
      await this.create({
        userId: 'Admin',
        password: hashedPassword
      });
      console.log('Default admin account created successfully');
    }
  } catch (error) {
    console.error('Error initializing admin:', error);
  }
};

const Admin = mongoose.model('Admin', adminSchema);

Admin.initializeAdmin();

module.exports = Admin;