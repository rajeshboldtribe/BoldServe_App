const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const Admin = require('../models/Admin');

// Initialize default admin account
const initializeDefaultAdmin = async () => {
    try {
        const defaultAdmin = await Admin.findOne({ userId: 'Admin' });
        if (!defaultAdmin) {
            const hashedPassword = await bcrypt.hash('Admin123', 10);
            await Admin.create({
                userId: 'Admin',
                password: hashedPassword
            });
            console.log('✅ Default admin account created successfully');
        }
    } catch (error) {
        console.error('❌ Error creating default admin:', error);
    }
};

// Call initialization when routes are loaded
initializeDefaultAdmin();

// Login route
router.post('/login', async (req, res) => {
    try {
        console.log('📝 Login attempt for userId:', req.body.userId);
        
        // Validate input
        if (!req.body.userId || !req.body.password) {
            return res.status(400).json({
                success: false,
                message: 'UserId and password are required'
            });
        }

        const { userId, password } = req.body;

        // Find admin by userId (case sensitive match for security)
        const admin = await Admin.findOne({ userId: userId });
        if (!admin) {
            console.log('❌ No admin found with userId:', userId);
            return res.status(401).json({
                success: false,
                message: 'Invalid credentials'
            });
        }

        // Verify password
        const isMatch = await bcrypt.compare(password, admin.password);
        if (!isMatch) {
            console.log('❌ Invalid password for userId:', userId);
            return res.status(401).json({
                success: false,
                message: 'Invalid credentials'
            });
        }

        // Create JWT token
        const token = jwt.sign(
            { 
                userId: admin.userId, 
                role: 'admin',
                timestamp: new Date().getTime()
            },
            process.env.JWT_SECRET || 'your_jwt_secret_key',
            { expiresIn: '24h' }
        );

        console.log('✅ Login successful for userId:', userId);

        res.json({
            success: true,
            token,
            message: 'Login successful',
            user: {
                userId: admin.userId,
                role: 'admin'
            }
        });

    } catch (error) {
        console.error('🔥 Login error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error during login',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
});

// Verify token route
router.get('/verify-token', async (req, res) => {
    try {
        const token = req.headers.authorization?.split(' ')[1];
        
        if (!token) {
            return res.status(401).json({
                success: false,
                message: 'No token provided'
            });
        }

        const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your_jwt_secret_key');
        const admin = await Admin.findOne({ userId: decoded.userId });

        if (!admin) {
            return res.status(401).json({
                success: false,
                message: 'Invalid token'
            });
        }

        res.json({
            success: true,
            user: {
                userId: admin.userId,
                role: 'admin'
            }
        });

    } catch (error) {
        console.error('🔥 Token verification error:', error);
        res.status(401).json({
            success: false,
            message: 'Invalid token'
        });
    }
});

// Logout route
router.post('/logout', (req, res) => {
    res.json({
        success: true,
        message: 'Logged out successfully'
    });
});

module.exports = router;