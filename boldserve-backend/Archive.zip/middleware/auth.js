const jwt = require('jsonwebtoken');

module.exports = (req, res, next) => {
  try {
    // Get token from Authorization header
    const token = req.headers.authorization?.split(' ')[1];
    
    if (!token) {
      return res.status(401).json({ 
        success: false,
        message: 'Authentication failed: No token provided' 
      });
    }

    // Verify token
    const decodedToken = jwt.verify(token, process.env.JWT_SECRET);
    
    // Add user data to request object
    req.user = { 
      id: decodedToken.userId,
      email: decodedToken.email // if you store email in token
    };

    // Log successful authentication (optional, for debugging)
    console.log('Authentication successful for user:', decodedToken.userId);

    next();
  } catch (error) {
    console.error('Authentication error:', error.message);
    return res.status(401).json({ 
      success: false,
      message: 'Authentication failed: Invalid token',
      error: error.message 
    });
  }
}; 